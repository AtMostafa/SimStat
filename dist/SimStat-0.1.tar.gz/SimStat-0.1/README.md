# SimStat

Small Python package for non-parametric statistical tests.

Now it includes bootstrap and permutation test.  I might add more functions as I need them later on.